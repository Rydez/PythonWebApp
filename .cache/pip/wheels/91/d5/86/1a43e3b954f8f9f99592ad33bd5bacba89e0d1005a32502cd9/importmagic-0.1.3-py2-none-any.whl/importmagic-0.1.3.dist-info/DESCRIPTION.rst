See http://github.com/alecthomas/importmagic for details.


