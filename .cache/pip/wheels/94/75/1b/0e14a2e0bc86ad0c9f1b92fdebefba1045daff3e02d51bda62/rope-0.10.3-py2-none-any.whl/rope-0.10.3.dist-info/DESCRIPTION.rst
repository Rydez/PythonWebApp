
.. _GitHub python-rope / rope: https://github.com/python-rope/rope


========================================
 rope, a python refactoring library ...
========================================


Overview
========

`Rope`_ is a python refactoring library.

.. _`rope`: https://github.com/python-rope/rope


New Features
============

* Under new management! Matěj Cepl <mcepl@cepl.eu> takes it hesitantly
  over
* Merged all availables pull requests and patches to the main codebase
* Tests are green again



